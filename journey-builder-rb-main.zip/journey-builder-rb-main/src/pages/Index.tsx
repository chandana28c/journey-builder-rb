import { useEffect } from "react";
import { useNavigate } from "react-router-dom";

const Index = () => {
  const navigate = useNavigate();

  useEffect(() => {
    navigate("/rb/01-problem", { replace: true });
  }, [navigate]);

  return null;
};

export default Index;
